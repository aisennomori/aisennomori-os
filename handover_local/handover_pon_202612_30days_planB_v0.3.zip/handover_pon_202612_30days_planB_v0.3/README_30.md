# 2026年12月1日〜30日 一括制作用 差分パッケージ（案B v1.2-proto）v0.3
2026-11-22 Aloha。内部検証・制作用。Instagram への投稿の承認ではない。

**このZIPは差分だけ**。次のファイルは、受け渡しパッケージ v0.1.1（handover_pon_v0.1.zip、SHA256 9932c0bd6adcffe56a1027f9ee673381476569eb8e4915639ccf034f27007565）のものを使う（中身は同一）。

| v0.1.1 から使うファイル | SHA256 |
|---|---|
| assets/bg_night_1080x1920.png | b1cfb562414c635b1bf313f0a0a1e686a51e2fff9f36162992e75e8e4c224858 |
| assets/bg_dawn_1080x1920.png | 2cd23870a99da2cf5f29c82fbae77fa8ff958ad9364e87fdb2d0763471e2fb5e |
| assets/moon_icons_alpha/moon_30.png | ae32cdaa5f6e1433916ff3095e55c8e549542fdb47bee1a7113bfdb5f3428a00 |
| templates/page2_dawn.html | a0dab30e9f8ba141047cb8f7dfec59870e0c91b1850704cd61edc17cc2e53e76 |
| reference_tool/data.py | b0c03f59b5a4d9dad4266ce8374c7f825d7349130aaae5a5b9fab16c0ba09847 |

- 背景2枚・月アイコン30個・2枚目テンプレート・data.py は v0.1.1 のものを使う（月アイコンは moon_01〜30 をすべて使う）。
- reference_tool/build_B.py は、v0.1.1 の reference_tool/data.py を同じフォルダに置いて使う。
- 12/9 再現検証用パッケージ（v0.2）の内容は、このZIPにすべて含まれる（12/9 のデータ・画像は同一）。

## 収録内容
| ファイル | 内容 |
|---|---|
| README_30.md | この説明 |
| README_B.md | 案B の最小仕様（日本の暦欄の内側、解説の選び方、合格基準） |
| templates/page1_night_B.html | 1枚目（案B 確定設定：解説 26px・top 110・行の高さ 1.3） |
| content/texts_B.json | 30日分の原稿（検証用原稿 v0.2 が正本）。p1_hint・p2_main・p2_echo（余韻＝アファメーション。非掲載の日は空）、affirmation（原文と掲載の有無）、card（カード名。画面には出さない）、status |
| content/expl_dict.json | 解説文の辞書 |
| content/config.json | 上限値と案B の設定 |
| data/handover_days_2026-12.json | 30日分の暦データ（項目単位）、案B の札・解説の期待値、外部照合の結果 |
| reference_images/2026-12-DD/ | 日ごとの参照画像（_01.jpg・_02.jpg、試作帯なし、1080×1920）と検証結果（_report.json。中の files のファイル名は作業時の名前 _01_B_PROTO.jpg・_02_B_PROTO.jpg で、ハッシュ値は参照画像と同じ） |
| reference_tool/build_B.py | 出力と検証の参考実装（`--no-mark` で帯なし出力） |
| SHA256SUMS.txt | このZIP内の全ファイルのハッシュ値 |

## 原稿の扱い
- 30日分の原稿は、検証用原稿 v0.2（Soul 通読済み）の文をそのまま使う。ポンの側で文章を変えない。
- status：`trial_approved`＝12/4・9・12（試作承認済み）、`soul_adopted_internal`＝ほかの27日（Soul の編集上の採用。内部検証用）。どちらも本番投稿の承認ではない。
- アファメーション：22日に掲載、8日は非掲載（2・3・6・8・10・25・27・28日）。20字を超えるものは「、」または「わたしは」の後で2行にしてある（p2_echo のとおりに描く）。
- カード連携の追加指定はない。カード名・カード画像は画面に出さない。

## 検証条件（60枚）
| 確認事項 | 基準 |
|---|---|
| 原稿 | ヒント・2枚目の本文・余韻が content/texts_B.json と1字・1改行も違わない |
| 暦 | data/handover_days_2026-12.json の全項目と一致 |
| 案B の暦欄 | 札と解説が、日ごとの期待値（data の「案B 暦欄」）と一致。解説した札に金の縁 |
| レイアウト | README_B.md と v0.1.1 の仕様どおり。2枚目は v0.1.1 と同じ |
| 文字の欠け・重なり | なし |
| 世界観 | 背景・ロゴ・ヘッダー・色・装飾が v0.1.1 と同じ |
| 出力 | 1080×1920、1日2枚（YYYY-MM-DD_01.jpg・_02.jpg）。同じ入力で同じ結果 |

- 画素の完全一致は必須ではない。原稿と暦の不一致は許容しない。
- 解説文は内部検証用の暫定承認（一粒万倍日は条件付き採用）。夜名・カード由来の文章を含め、公開利用は未確認。
