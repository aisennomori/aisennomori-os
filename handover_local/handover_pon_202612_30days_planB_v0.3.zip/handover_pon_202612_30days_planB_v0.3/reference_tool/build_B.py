"""愛泉の杜 Daily Stories 案B 試作テンプレート v1.2-proto の出力と検証（内部検証用・未承認）
使い方: python3 tool/build_B.py 2026-12-04 [--no-mark]
- 1枚目：templates/page1_night_B.html（日本の暦欄だけ案B）。2枚目：templates/page2_dawn.html（本番 v1.1 と同一）
- 暦は正本から取得（tool/data.py）。原稿は content/texts_B.json、解説文は content/expl_dict.json
- 解説の選択：R-1 二十四節気 → 吉日（表示順）→ 凶日 → 六曜。R-3 己巳の日の日は巳の日を出さない。R-4 祝日は札のみ。R-6 辞書になければ出さない
- 本番テンプレート・本番画像は変更しない。出力は out/ に「_B_PROTO」付きで保存する
"""
import sys, json, asyncio, pathlib, time, hashlib
from PIL import Image, ImageDraw, ImageFont
T0 = time.time()
TL = pathlib.Path(__file__).parent; R = TL.parent
sys.path.insert(0, str(TL)); from data import day
from playwright.async_api import async_playwright
CFG = json.load(open(R / 'content/config.json', encoding='utf-8'))
DIC = json.load(open(R / 'content/expl_dict.json', encoding='utf-8'))
TX = json.load(open(R / 'content/texts_B.json', encoding='utf-8'))
HDR = ['#brand .jp', '#brand .en', '#title', '#rule', '#sub', '#badge', '#date', '#phase', '#phaseSub']
RECT = """(S)=>S.map(s=>{const e=document.querySelector(s);const r=document.createRange();r.selectNodeContents(e);const q=(e.tagName==='svg'||e.id==='badge')?e.getBoundingClientRect():r.getBoundingClientRect();return [s,Math.round(q.left),Math.round(q.top),Math.round(q.width),Math.round(q.height),getComputedStyle(e).fontSize]})"""
LINES = """(s)=>{const e=document.querySelector(s);const r=document.createRange();r.selectNodeContents(e);const t=[...r.getClientRects()].filter(x=>x.width>2).map(x=>x.top).sort((a,b)=>a-b);let n=t.length?1:0;for(let i=1;i<t.length;i++)if(t[i]-t[i-1]>20)n++;return n}"""
CHECK1 = """()=>{const o=[];const card=id=>document.getElementById(id).getBoundingClientRect();const rr=e=>{const g=document.createRange();g.selectNodeContents(e);return g.getBoundingClientRect()};
 const jp=card('jp'),hw=card('hw'),hi=card('hint');
 const ch=document.getElementById('chips'),ex=document.getElementById('expl');
 const a=rr(ch); if(a.left<jp.left+10||a.right>jp.right-24) o.push('札の行が欄の外');
 const tops=new Set([...ch.querySelectorAll('.chip')].map(x=>Math.round(x.getBoundingClientRect().top))); if(tops.size>1) o.push('札が2行に折り返し');
 if(ex.textContent.trim()){const b=rr(ex); if(b.right>jp.right-24||b.left<jp.left+10) o.push('解説が欄の左右を超える'); if(b.bottom>jp.bottom-4) o.push('解説が欄の下端を超える'); if(b.top<a.bottom+2) o.push('解説が札に重なる');}
 for(const s of ['#hwName','#hwKana','#hwNo']){const e=document.querySelector(s);const q=rr(e);if(q.left<hw.left+10||q.right>hw.right-10||q.top<hw.top+4||q.bottom>hw.bottom-6)o.push('枠外 '+s)}
 const ic=document.getElementById('hwIcon').getBoundingClientRect(); if(ic.left<hw.left||ic.right>hw.right||ic.top<hw.top||ic.bottom>hw.bottom) o.push('月アイコンがカード外');
 {const r1=rr(document.getElementById('hwName')),r2=rr(document.getElementById('hwNo'));if(r1.right>r2.left-10)o.push('夜名が第N夜に重なる'); if(r2.right>ic.left-10)o.push('第N夜が月アイコンに重なる')}
 {const q=rr(document.getElementById('hintText')); if(q.left<hi.left+10||q.right>hi.right-10||q.bottom>hi.bottom-6) o.push('ヒントが枠外')}
 if(hi.bottom>1262) o.push('ヒント欄が家・灯籠にかかる');
 const img=document.getElementById('hwIcon'); if(!img.complete||!img.naturalWidth) o.push('月アイコンが読み込めない');
 return o}"""
CHECK2 = """()=>{const o=[];const rr=s=>{const e=document.querySelector(s);const r=document.createRange();r.selectNodeContents(e);return r.getBoundingClientRect()};
 const m=rr('#main'),h=rr('#p2head'); if(m.top<h.bottom+20) o.push('見出しと本文が重なる'); if(m.left<100||m.right>980) o.push('本文が左右の範囲外');
 const box=document.getElementById('main').getBoundingClientRect(); if(m.top<box.top-1||m.bottom>box.bottom+1) o.push('本文が本文枠を超える'); if(m.bottom>1300) o.push('本文が朝日にかかる');
 const e=document.getElementById('echo'); if(getComputedStyle(e).display!=='none'){const q=rr('#echo'); if(q.top<m.bottom+10) o.push('余韻が本文に重なる'); if(q.bottom>1330) o.push('余韻が朝日にかかる')}
 return o}"""
SAFE = """()=>{const o=[];document.querySelectorAll('#stage *').forEach(e=>{if(['svg','path','circle','g','defs','filter','feGaussianBlur','ellipse','IMG'].includes(e.tagName)&&e.id!=='hwIcon')return; if(!e.textContent.trim()&&e.id!=='hwIcon')return; if(getComputedStyle(e).display==='none'||getComputedStyle(e).visibility==='hidden')return;
  const r=e.getBoundingClientRect(); if(r.height&&(r.top<195||r.bottom>1725)&&!e.classList.contains('note')&&e.id!=='testMark'&&e.id!=='protoMark') o.push('安全領域外 '+(e.id||e.className))});return [...new Set(o)]}"""
DOM1 = """()=>({date:document.getElementById('date').textContent,phase:document.getElementById('phase').textContent,phaseSub:document.getElementById('phaseSub').textContent,
  days:document.getElementById('days').textContent,
  chips:[...document.querySelectorAll('#chips .grp')].map(g=>[g.querySelector('.lab').textContent,[...g.querySelectorAll('.chip')].map(c=>c.textContent)]),
  on:[...document.querySelectorAll('#chips .chip.on')].map(c=>c.textContent),expl:document.getElementById('expl').textContent,
  hwName:document.getElementById('hwName').textContent,hwNo:document.getElementById('hwNo').textContent,hwKana:document.getElementById('hwKana').textContent,
  icon:document.getElementById('hwIcon').src,hint:document.getElementById('hintText').innerText})"""
DOM2 = """()=>({date:document.getElementById('date').textContent,phase:document.getElementById('phase').textContent,phaseSub:document.getElementById('phaseSub').textContent,
  main:document.getElementById('main').innerText,echo:getComputedStyle(document.getElementById('echo')).display==='none'?'':document.getElementById('echo').innerText})"""

def select(D):
    """R-1〜R-6：解説の選択（自動）。戻り値：(解説 dict or None, 理由)"""
    order = DIC['order_kichi']; E = DIC['entries']
    kc = [s for s in D['senchu'] if s != '不成就日']
    if '己巳の日' in kc: kc = [s for s in kc if s != '巳の日']
    cands = ([D['sekki']] if D['sekki'] else []) + sorted(kc, key=order.index) + (['不成就日'] if '不成就日' in D['senchu'] else []) + [D['rokuyo']]
    for c in cands:
        if c in E: return {'label': c, 'text': E[c]['text'], 'status': E[c]['status']}, '候補 ' + '→'.join(cands) + f' のうち、辞書にある最初の「{c}」'
    return None, '候補 ' + '→'.join(cands) + ' はいずれも辞書になし（解説は出さない）'

def expect_chips(D):
    kc = [s for s in D['senchu'] if s != '不成就日']
    if '己巳の日' in kc: kc = [s for s in kc if s != '巳の日']
    kc.sort(key=DIC['order_kichi'].index)
    out = [['六曜', [D['rokuyo']]]]
    if kc: out.append(['吉日', kc])
    if '不成就日' in D['senchu']: out.append(['凶日', ['不成就日']])
    sk = [x for x in [D['sekki'], D['holiday']] if x]
    if sk and CFG.get('show_season'): out.append(['季節', sk])
    return out

async def build(d, mark=True):
    D = day(d); X = TX.get(d)
    if not X: raise SystemExit(f'STOP {d}: 原稿がない')
    ex, why = select(D)
    out = R / 'out' / d; out.mkdir(parents=True, exist_ok=True)
    rep = {'date': d, 'template': 'v1.2-proto（案B・内部検証用）', 'text_source': X['source'], 'expl': ex, 'expl_reason': why}
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={'width': 1080, 'height': 1920})
        T1 = {'bg': (R / 'assets/bg_night_1080x1920.png').as_uri(), 'iconDir': (R / 'assets/moon_icons_alpha').as_uri(), 'showPeriod': False, 'test': False,
              'hint': X['p1_hint'], 'notes': [], 'expl': ex, 'showSeason': CFG.get('show_season', True), 'explSize': CFG['expl_px'],
              'proto': '内部検証用の試作（未承認）｜案B テンプレート v1.2-proto' if mark else ''}
        await pg.goto((R / 'templates/page1_night_B.html').as_uri()); await pg.evaluate("([D,T])=>render(D,T)", [D, T1]); await pg.wait_for_timeout(500)
        c1 = await pg.evaluate(CHECK1) + await pg.evaluate(SAFE); h1 = await pg.evaluate(RECT, HDR); dom1 = await pg.evaluate(DOM1)
        hl = await pg.evaluate(LINES, '#hintText'); want = sum(len(x.split('\n')) for x in X['p1_hint'])
        if hl != want: c1.append(f'ヒントの想定外の折り返し {hl}/{want}')
        if ex and await pg.evaluate(LINES, '#expl') > 1: c1.append('解説が2行に折り返し')
        ew = await pg.evaluate("()=>{const r=document.createRange();r.selectNodeContents(document.getElementById('expl'));return Math.round(r.getBoundingClientRect().width)}")
        await pg.screenshot(path=str(out / f'{d}_01_B_PROTO.jpg'), type='jpeg', quality=93)
        main = X['p2_main']; fs48 = any(len(l) > CFG['main_max']['chars'] for l in main if l); stanza = '' in main
        T2 = {'bg': (R / 'assets/bg_dawn_1080x1920.png').as_uri(), 'main': '\n'.join(main), 'mainLines': main if (stanza or fs48) else None, 'fs48': fs48, 'echo': '\n'.join(X['p2_echo']), 'notes': []}
        await pg.goto((R / 'templates/page2_dawn.html').as_uri()); await pg.evaluate("([D,T])=>render(D,T)", [D, T2]); await pg.wait_for_timeout(500)
        c2 = await pg.evaluate(CHECK2) + await pg.evaluate(SAFE); h2 = await pg.evaluate(RECT, HDR); dom2 = await pg.evaluate(DOM2)
        if await pg.evaluate(LINES, '#main') != len([l for l in main if l]): c2.append('本文の想定外の折り返し')
        await pg.screenshot(path=str(out / f'{d}_02_B_PROTO.jpg'), type='jpeg', quality=93)
        await b.close()
    # 正本・原稿との照合
    ev = D['event']; mm = []
    E = {'date': f"{D['md']}（{D['wd']}）", 'phase': ev['label'] if ev else '', 'phaseSub': f"{ev['time']}・{ev['sign']}" if ev and ev['time'] else ''}
    for k in E:
        if dom1[k] != E[k]: mm.append(f'1枚目 {k}「{dom1[k]}」≠正本「{E[k]}」')
        if dom2[k] != E[k]: mm.append(f'2枚目 {k}「{dom2[k]}」≠正本「{E[k]}」')
    days = ('この日が満月' if D['to_full'] == 0 else f"満月まで あと{D['to_full']}日") + ('この日が新月' if D['to_new'] == 0 else f"新月まで あと{D['to_new']}日")
    if dom1['days'].replace(' ', '') != days.replace(' ', ''): mm.append(f"日数「{dom1['days']}」≠正本「{days}」")
    if dom1['chips'] != expect_chips(D): mm.append(f"札 {dom1['chips']}≠正本 {expect_chips(D)}")
    if ex and (dom1['expl'] != f"{ex['label']}｜{ex['text']}" or dom1['on'] != [ex['label']]): mm.append(f"解説の表示が選択結果と違う：{dom1['expl']}")
    for k, v in [('hwName', D['night']['name']), ('hwKana', D['night']['kana']), ('hwNo', f"第{D['night']['n']}夜")]:
        if dom1[k] != v: mm.append(f'{k}「{dom1[k]}」≠正本「{v}」')
    if not dom1['icon'].endswith('/' + D['night']['icon']): mm.append('月アイコンが夜番号と違う')
    if dom1['hint'].replace('\n', '') != ''.join(X['p1_hint']).replace('\n', ''): mm.append('ヒントが原稿と違う')
    if dom2['main'].replace('\n', '') != ''.join(main): mm.append('2枚目の本文が原稿と違う')
    if dom2['echo'].replace('\n', '') != ''.join(X['p2_echo']): mm.append('余韻が原稿と違う')
    hd = [a[0] for a, c in zip(h1, h2) if a[1:] != c[1:]]
    rep['checks'] = {'1枚目配置': c1 or '問題なし', '2枚目配置': c2 or '問題なし', '正本・原稿との照合': mm or '一致',
                     '共通ヘッダー': '一致（9項目）' if not hd else f'差あり {hd}', '解説の幅': f'{ew}px（上限 {CFG["expl_max_px"]}px）',
                     '表示データ': {'日付': dom1['date'], '月相': dom1['phase'] or '（節目ではない日：表示なし）', '時刻・星座': dom1['phaseSub'] or 'なし', '日数': dom1['days'],
                                 '札': dom1['chips'], '解説': dom1['expl'] or 'なし', '夜': f"{dom1['hwName']}／{dom1['hwKana']}／{dom1['hwNo']}", '月アイコン': dom1['icon'].split('/')[-1]}}
    rep['files'] = {f.name: hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(out.glob(f'{d}_0?_B_PROTO.jpg'))}
    rep['elapsed_sec'] = round(time.time() - T0, 2)
    json.dump(rep, open(out / f'{d}_report_B.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(json.dumps(rep, ensure_ascii=False, indent=1))

if __name__ == '__main__':
    asyncio.run(build(sys.argv[1], mark='--no-mark' not in sys.argv))
